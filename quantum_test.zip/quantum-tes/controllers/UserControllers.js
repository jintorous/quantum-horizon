const utils= require("../utils/users.utils");
const {readFileUsers,readFileTasks,createJwt,writeFileUsers,writeFileTasks,createResponses}=require("../helpers/helpers")
async function listUsers(req, res) {
    let users = await readFileUsers();
    console.log(users, "res")
    res.send(200, users)
}

async function listAllTasks(req, res) {
    let users = await readFileTasks();
    console.log(users, "res")
    res.send(200, users)
}

async function listTasksWithId(req, res) {
    let id = req.params.id;
    console.log(id)
    let tasks = await readFileTasks();
    let resuslt = {};
    for (let elem of tasks) {
        if (elem.Task_id == id) {
            resuslt = elem;
            break;
        }
    }
    res.send(200, resuslt)
}
async function createUsers(req, res) {
    let body = req.body;
    let result = await utils.createUsers(body);
    console.log(result);
    res.send(200, createResponses(result))
}
async function login(req, res) {
    let body = req.body;
    let result = await utils.login(body);
    console.log(result);
    res.send(200, createResponses(result))
}
async function createTask(req, res) {
    let body = req.body;
    let result = await utils.createTask(body);
    console.log(result);
    res.send(200, createResponses(result))
}

module.exports={
    listUsers,
    listAllTasks,
    listTasksWithId,
    createUsers,
    login,
    createTask

}