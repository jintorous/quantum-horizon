const fs = require("fs");
var jwt = require('jsonwebtoken');
let secretKey = "apls"; //this will be stored in .env .. for time constraints i am not using .env construct


const readFileUsers = async () => {
    return new Promise(async (resolve, reject) => {
        const users = await fs.readFileSync("./users.json", "utf-8");
        resolve(JSON.parse(users));
    })
}

const readFileTasks = async () => {
    return new Promise(async (resolve, reject) => {
        const users = await fs.readFileSync("./tasks.json", "utf-8");
        resolve(JSON.parse(users));
    })
}
const createJwt = (data) => {
    var token = jwt.sign(data, secretKey, { expiresIn: '1h' });
    return { token }
}

const writeFileUsers = async (data) => {
    const users = await fs.writeFileSync("./users.json", data);
    return users;
}
const writeFileTasks = async (data) => {
    const users = await fs.writeFileSync("./tasks.json", data);
    return users;
}
const createResponses = (details) => {
    let result = { details }
    return result;
}
module.exports = {
    readFileUsers,
    readFileTasks,
    createJwt,
    writeFileUsers,
    writeFileTasks,
    createResponses
}