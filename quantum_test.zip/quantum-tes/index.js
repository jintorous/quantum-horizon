const express = require('express')
const bodyParser = require('body-parser')
const app = express();
// const connectToMongoDB = require('./db/connect');
const validateRequest = require('./middleWares/validation.middleware');
const { userSchema, taskSchema } = require('./validators/main.validator');

const { listUsers, listAllTasks, listTasksWithId, createUsers, login, createTask } = require("./controllers/UserControllers")
const { verifyJWT } = require("./middleWares/authorisation.middleware");
const { readFileUsers, readFileTasks, createJwt, writeFileUsers, writeFileTasks, createResponses } = require("./helpers/helpers")
app.use(bodyParser.urlencoded({ extended: false }))

app.use(bodyParser.json())

app.get('/listUsers', listUsers)
app.get('/listAllTasks', verifyJWT, listAllTasks)
app.get('/listTasksWithId/:id', verifyJWT, listTasksWithId)


app.post("/createUsers", validateRequest(userSchema), createUsers)

app.post("/login", login)
app.post("/createTask", validateRequest(taskSchema), verifyJWT, createTask)



app.listen(3000, async () => {
    // const client = await connectToMongoDB();

    console.log(`app running on 3000`)
})