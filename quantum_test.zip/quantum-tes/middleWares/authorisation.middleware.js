const {readFileUsers,readFileTasks,createJwt,writeFileUsers,writeFileTasks,createResponses}=require("../helpers/helpers")
const utils= require("../utils/users.utils");

var jwt = require('jsonwebtoken');
let secretKey = "apls"; 

const verifyJWT = async (req, res, next) => {
    try {
        let token = req.headers.authorization;
        if (!token) {
            return  res.send(400, {
                status: false,
                message: "Auth Token is needed"
            })
        }
        var decoded = jwt.verify(token, secretKey);
        if (!decoded) {
            return res.send(400, {
                status: false,
                message: "invalid token"
            })
        }
        let users = await readFileUsers();
        let userExistsFlag = utils.checkUserExists(users, decoded);
        if (!userExistsFlag.status) {
           return res.send(400, {
                status: false,
                message: "user not exists"
            })
        }
        req["user"] = {
            userName: decoded.userName
        }
        next();

    }
    catch (error) {
        return res.send(500, {
            status: false,
            message: "invalid token"
        })
    }
}

module.exports={
    verifyJWT
}