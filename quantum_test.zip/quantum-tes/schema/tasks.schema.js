
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const taskSchema = new Schema({
  startDate: {
    type: String,
    required: true
  },
  dateOfCompletion: {
    type: Date,
    required: true
  },
  dueDate: {
    type: Date,
    required: true
  },
  desc: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['todo', 'wip', 'done'],
    required: true
  },
  userName: {
    type: String,
    required: true
  }
}, {
  timestamps: true 
});

module.exports = mongoose.model('Task', taskSchema);
