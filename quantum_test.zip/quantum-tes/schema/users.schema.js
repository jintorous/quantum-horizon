
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
  userName: {
    type: String,
    required: true
  },
  occupation: {
    type: String,
    required: false
  },
  firstName: {
    type: String,
    required: true
  },
  lastName: {
    type: String,
    required: false
  },
  salary: {
    type: Number,
    required: false
  },
  password: {
    type: String,
    minlength: 6,
    required: true
  }
});

module.exports = mongoose.model('User', userSchema);
