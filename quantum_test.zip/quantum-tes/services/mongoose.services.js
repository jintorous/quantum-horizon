
async function Create(Model, data) {
    try {
        const document = new Model(data);
        await document.save();
        return document;
    } catch (error) {
        throw error;
    }
}

async function Update(Model, id, updateData) {
    try {
        const document = await Model.findByIdAndUpdate(id, updateData, { new: true });
        return document;
    } catch (error) {
        throw error;
    }
}

async function BulkUpdate(Model, filter, updateData) {
    try {
        const result = await Model.updateMany(filter, updateData);
        return result;
    } catch (error) {
        throw error;
    }
}

async function BulkCreate(Model, documentsData) {
    try {
        const result = await Model.insertMany(documentsData);
        return result;
    } catch (error) {
        throw error;
    }
}
async function findAllDocuments(Model, condition) {
    try {
        const documents = await Model.find(condition);
        return documents;
    } catch (error) {
        throw error;
    }
}

async function findOneDocument(Model, condition) {
    try {
        const document = await Model.findOne(condition);
        return document;
    } catch (error) {
        throw error;
    }
}
async function findDocumentsWithPaging(Model, condition, page, perPage=10) {
    try {
        const skip = (page - 1) * perPage;
        if (perPage > 100)
            perPage = 100
        const documents = await Model.find(condition)
            .skip(skip)
            .limit(perPage);
        return documents;
    } catch (error) {
        throw error;
    }
}

module.exports = {
    Create,
    Update,
    BulkUpdate,
    BulkCreate,
    findDocuments,
    findOneDocument,
    findDocumentsWithPaging
};
