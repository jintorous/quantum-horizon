const {readFileUsers,readFileTasks,createJwt,writeFileUsers,writeFileTasks,createResponses}=require("../helpers/helpers")

const bcrypt = require('bcrypt');
const saltRounds = 10;


const checkUserExists = (users, details) => {
    console.log(users, details)
    for (let elem of users) {
        if (elem.userName == details.userName) {
            return {
                status: true,
                data: elem
            }
        }
    }
    return {
        status: false,
        data: null
    };

}

const createUsers = async (details) => {
    let users = await readFileUsers();
    let userExistsFlag = checkUserExists(users, details);
    if (userExistsFlag.status) {
        return ({
            status: false,
            message: "user already exists"
        })
    }
    else {
        const salt = await bcrypt.genSaltSync(saltRounds);
        const hash = await bcrypt.hashSync(details.password, salt);
        console.log(hash)
        details.password = hash;
        details["user_id"]=users.length;
        users.push(details);
        writeFileUsers(JSON.stringify(users))
        return {
            status: true,
            message: "user inserted"
        }
    }
}

const login = async (details) => {
    let users = await readFileUsers();
    let userExistsFlag = checkUserExists(users, details);
    if (!userExistsFlag.status) {
        return ({
            status: false,
            message: "user not exists"
        })
    }
    else {
        console.log(details.password, userExistsFlag.password);
        let mached = bcrypt.compareSync(details.password, userExistsFlag.data.password);
        if (!mached) {
            return ({
                status: false,
                message: "userName password combination is not valid"
            })
        }
        else {
            let jwtData = {
                userName: userExistsFlag.data.userName
            }
            let token = createJwt(jwtData);
            let resultData = {
                firstName: userExistsFlag.data.firstName,
                lastName: userExistsFlag.data.lastName,
                userName: userExistsFlag.data.userName,
                token
            }
            return ({
                status: true,
                data: resultData
            })

        }
    }
}

const checkStatus = (status) => {
    if (status == 'WIP' || status == 'TO DO' || status == 'DONE')
        return true;
    else
        return false
}

const createTask = async (details) => {
    let Tasks = await readFileTasks();
    if (!checkStatus(details.Status)) {
        return ({
            status: false,
            message: "The status must be WIP or TO DO or Done"
        })
    }
    details["Task_id"]=Tasks.length;
    Tasks.push(details);
    writeFileTasks(JSON.stringify(Tasks))
}

module.exports={
    createUsers,
    login,
    checkUserExists,
    createTask
}