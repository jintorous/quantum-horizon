const Joi = require('joi');

const userSchema = Joi.object({
    userName: Joi.string().min(3).max(30).required(),
    occupation: Joi.string().min(3).max(30).required(),
    firstName: Joi.string().min(3).max(30).required(),
    lastName: Joi.string().min(3).max(30).required(),
    salary: Joi.number().required(),
    password: Joi.string().min(6).required()
});


const taskSchema = Joi.object({
    startDate: Joi.string().min(3).max(30).required(),
    DateOfComplition: Joi.string().min(3).max(30).required(),
    DueDate: Joi.string().min(3).max(30).required(),
    Desc: Joi.string().min(3).max(30).required(),
    status: Joi.string().valid('todo', 'wip','done').required(),
    userName: Joi.string().min(3).max(30).required(),

});

module.exports = { userSchema ,taskSchema};

